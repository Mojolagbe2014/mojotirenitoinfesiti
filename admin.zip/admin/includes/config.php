<?php
/*define(DB_HOST,"72.167.233.111");
define(DB_USER,"traininvest123");
define(DB_PASS,"Train1234!");
define(DB_NAME,"traininvest123");

define(DB_HOST,"localhost");
define(DB_USER,"cpses_ch4N8i9X03@train2invest.com");
define(DB_PASS,"Train1234!");
define(DB_NAME,"train2invest");
*/
define(DB_HOST,"localhost");
define(DB_USER,"train2invest");
define(DB_PASS,"P@ss123!");
define(DB_NAME,"train2invest");
?>